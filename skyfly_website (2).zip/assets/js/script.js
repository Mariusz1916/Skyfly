
/* SkyFly – prosta interaktywność */
document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Pseudo rezerwacja – demo
  const form = document.getElementById('bookingForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      const msg = `Dziękujemy! Wstępna rezerwacja: ${data.product} | ${data.date} | ${data.name}`;
      alert(msg);
      form.reset();
    });
  }
});
